#ifndef __wasm_basics___typedef_gid_t_h
#define __wasm_basics___typedef_gid_t_h

typedef unsigned gid_t;

#endif

#ifndef __wasm_basics___typedef_off_t_h
#define __wasm_basics___typedef_off_t_h

/* Define these as 64-bit signed integers to support files larger than 2 GiB. */
typedef long long off_t;

#endif
